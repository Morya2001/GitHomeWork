﻿using System;
using System.Collections.Generic;

namespace Book.DAL.Entities;

public partial class BooksGit
{
    public int BookId { get; set; }

    public string? BookName { get; set; }
}
