﻿namespace Book.API.Models
{
    public class BookRequest
    {
        public int BookId { get; set; }

        public string? BookName { get; set; }
    }
}
