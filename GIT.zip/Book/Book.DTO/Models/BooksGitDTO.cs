﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book.DTO.Models
{
    public class BooksGitDTO
    {
        public int BookId { get; set; }

        public string? BookName { get; set; }
    }
}
